# Backend Architecture Documentation

_Started 2026-05-04 15:14 UTC_

---

## User

Create supporting diagrams and documentations for this project. I am happy with the current front-end. We need now to document and design PRDs and supporting documentation for the backend. Our scope is not to develop the back-end, but to create the design to be implemented later. Let's start by creating a new folder with the architectural design of the Camel/Debezium/Kafka pipeline and the mongodb mappings and documentation. 

For generating the manifests we will use Helm as the template engine. 

Camel must be able to consume the debezium event, transform the payload into helm readable and data and send the manifest into gitea repo. For this design, we can abstract gitea for now and reference a git repo. Kafka topics and structure must have proper deadletter queues and be properly organized accordingly with our current desing.

## Assistant

_[tool: list_files]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: update_todos]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: write_file]_

Now I have a complete picture of the system. Let me build the architecture documentation.

_[tool: copy_files]_

_[tool: write_file]_

_[tool: done]_

_[tool: fork_verifier_agent]_

_[tool: update_todos]_

The backend architecture documentation is ready in `backend-architecture/`. It's an interactive single-page doc matching the gdfkube design language, with seven sections:

1. **Pipeline Overview** — end-to-end flow diagram (Express → MongoDB → Debezium → Kafka → Camel → Helm → Git), design principles, tech stack, sequence diagram
2. **MongoDB Schemas** — `requests`, `forms`, and `audit_log` collections with full document schemas and indexes
3. **Debezium CDC** — KafkaConnector CR with SMTs, CDC event structure after `ExtractNewDocumentState`, watched operations
4. **Kafka Topics & DLQ** — 8-topic registry (3 CDC/internal + 4 DLQs), naming conventions, DLQ error flow with retry/backoff/header enrichment, KafkaTopic CRs
5. **Camel Routes** — Full YAML DSL for `request-router` (main pipeline), `helm-render` and `git-push` sub-routes, error handlers routing to specific DLQ topics
6. **Helm Templates** — Chart structure per formId, CDC→values.yaml mapping via `helmValuesBuilder`, `hostedcluster.yaml` and `_helpers.tpl` templates
7. **Git Repo Structure** — Per-org repo layout, directory mapping by formId, commit conventions, ArgoCD ApplicationSet reference

Key design decisions:
- **DLQs are granular**: separate topics for connector errors, request processing, Helm render failures, and Git push failures
- **Helm is template-only** — no releases, no state; pure `helm template` invocation
- **Camel uses manual Kafka commit** — offset committed only after successful Git push for exactly-once semantics

## User

Apply comment

## Assistant

_[tool: read_file]_

I need to update three areas: the Git section (repo bootstrap), the Camel section (git-push sub-route with repo creation), and the route inventory.

_[tool: str_replace_edit]_

_[tool: done]_

_[tool: fork_verifier_agent]_

Updated three areas:

1. **Git section** — new "First-Request Repo Bootstrap" card documenting the cold-start flow: existence check via API → create repo → clone → scaffold directories → commit & push, with idempotency guarantees for concurrent first-requests.

2. **Camel section** — added `repo-bootstrap` sub-route (full YAML DSL) called before clone in `git-push`. It hits the Git server API, creates the repo on 404, writes the scaffold structure, and handles errors to the git-push DLQ.

3. **Route inventory** — added `repo-bootstrap` row to the table.

## User

Verifier agent check completed

## Assistant

All clear — the repo bootstrap documentation is rendering correctly across both sections. Let me know if you'd like to expand any area or add more documentation (e.g. Debezium signal handling, RBAC design, or monitoring/alerting specs).

## User

Analyze the attached file. The file is an architecture reference for the RHACM and ArgoCD configurations. Analyze it and adjust it to fit into our current design. Prioritize our current state.

## Assistant

_[tool: read_file]_

_[tool: update_todos]_

Good analysis material. Key findings from the reference doc:

1. **Two-repo model** — we're missing `gdfkube-infra` (shared platform resources). On new-org bootstrap, Camel must push to *both* repos.
2. **ArgoCD** — bootstrap discovery ApplicationSet, per-org AppProjects with RBAC isolation, auto-sync disabled for customer manifests.
3. **RHACM** — flat per-org ManagedClusterSet model, exclusive clusterset labels, pre-created ManagedCluster to avoid default assignment.
4. **Customer repo uses Kustomize** — `base/` + `kustomization.yaml` per cluster, not flat files.
5. **Richer labels** — `setic.gov.br/*` and `gdfkube.io/*` namespaces, HyperShift auto-import annotations.
6. **RBAC** — setic-platform-admin / setic-operator roles, customers get zero hub access.
7. **Gitea templating** — `giteaExternalUrl` and `giteaOwner` variables instead of hardcoded URLs.

Let me integrate all of this. I'll update existing sections and add RHACM/ArgoCD and RBAC sections to the nav.

_[tool: read_file]_

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

Now let me update the Overview section to reflect the two-repo model, update the Git section with `gdfkube-infra` and Kustomize structure, update the Camel bootstrap to push to both repos, update Helm templates with richer labels, and add the two new sections. I'll do this in a few edits.

_[tool: str_replace_edit]_

Now let me update the Git section to include the `gdfkube-infra` repo and switch customer repos to Kustomize structure:

_[tool: str_replace_edit]_

## User

No, like i've said. Prioritize the current architecture. We are using helm as template renderes and for all argocd related actions, not kustomize. Same goes for folder structures and etc. If unsure, askme which option to go with

## Assistant

_[tool: read_file]_

Understood — our current Helm-based flat manifest structure stays. I'll only integrate:

- **gdfkube-infra** repo with its ArgoCD/RHACM org directories
- **ArgoCD** bootstrap discovery, per-org AppProjects, ApplicationSets (auto-sync disabled)
- **RHACM** flat per-org ManagedClusterSet model, pre-created ManagedCluster with rich labels
- **RBAC** model (setic-platform-admin, setic-operator)
- **Camel bootstrap** pushes to both repos (infra + customer)
- **Gitea variables** (`giteaExternalUrl`, `giteaOwner`)
- **Richer ManagedCluster labels/annotations** in our existing Helm templates

No Kustomize, no folder restructuring. Let me apply these.

_[tool: read_file]_

_[tool: read_file]_

Now I have the full picture. Let me apply all the changes in one batch:

_[tool: str_replace_edit]_

Now update the Helm values mapping to include richer labels, Gitea variables, and the bootstrap to push to gdfkube-infra:

_[tool: str_replace_edit]_

Now update the ManagedCluster Helm template and the Camel bootstrap to push to both repos. Then add the ArgoCD/RHACM and RBAC sections:

_[tool: str_replace_edit]_

Now update the bootstrap flow description in the Git section and add the two new sections. Let me update the bootstrap flow first:

_[tool: str_replace_edit]_

Now add the ArgoCD/RHACM and RBAC sections at the end, before the mount:

_[tool: str_replace_edit]_

_[tool: done]_

_[tool: read_file]_

I see — the InfoBox from my earlier edit got malformed with leftover code. Let me fix it:

_[tool: str_replace_edit]_

_[tool: done]_

_[tool: fork_verifier_agent]_

_[tool: update_todos]_

_[tool: snip]_

All integrated. Here's what changed from the reference doc, adapted to our Helm-based architecture:

**New sections:**
- **ArgoCD & RHACM** — bootstrap discovery ApplicationSet, per-org AppProjects (Helm-rendered), flat ManagedClusterSet model with exclusive labels, pre-created ManagedCluster, Placement examples
- **RBAC & Access** — permission model diagram, access matrix, setic-platform-admin and setic-operator ClusterRoles, customer kubeconfig retrieval

**Updated sections:**
- **Git Repo Structure** — added `gdfkube-infra` repo with `argocd/orgs/`, `rhacm/orgs/`, `rbac/` layout and ownership table
- **Camel Routes** — bootstrap now renders `org-infra` Helm chart and pushes ArgoCD + RHACM manifests to `gdfkube-infra` (8-step flow)
- **Helm Templates** — added `org-infra` chart (appproject, applicationset, managedclusterset, binding), richer label schema with `setic.gov.br/*` and `gdfkube.io/*`, HyperShift auto-import annotations, `giteaExternalUrl`/`giteaOwner` templating, `gdfkube.repoURL` helper
- **Overview** — added "Two-repo model" design principle

**Preserved from our current design:** Helm as sole template engine, flat manifest directories (no Kustomize), all existing topic/DLQ structure.

## User

We need to add to the docs how RHACM and HyperShift will handle secret keys for cluster creation. Please analyze the following and implement into ao architecture.

## Assistant

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

_[tool: done]_

Those are just React warnings (not errors) — the Fragment prop warning is from the editor runtime injecting `data-om-id`, and `ReactDOM.render` is a harmless React 17 compat warning. The app renders correctly. Let me verify:

_[tool: fork_verifier_agent]_

The **Secret Handling** section is now live. It documents:

- **Credential flow** — central `kubevirt-secret` in `open-cluster-management` → RHACM ConfigurationPolicy → injected into every `hc-*` namespace
- **Injected secrets table** — pull-secret and sshkey with source/target mapping, types, data keys, cleanup behavior
- **Full ConfigurationPolicy YAML** — both `inject-hc-pull-secret` and `inject-hc-sshkey` with hub templating, PlacementBinding
- **Service account roles** — hypershift-addon-agent-sa, hypershift-addon-manager-sa, provider-credential, argocd-manager with clear separation of RHACM vs ArgoCD SAs
- **HostedCluster references** — how the Helm template references `pull-secret` and `sshkey`, and why the pipeline is decoupled from secret distribution (HyperShift retries, no coordination needed)
- **Explicit note** that this project uses raw HostedCluster manifests via ArgoCD (not HypershiftDeployment CRs)

## User

Verifier agent check completed

## Assistant

All verified and rendering correctly. The documentation now covers 10 sections end-to-end. Let me know if you'd like to add more — monitoring/alerting specs, disaster recovery procedures, or anything else.

