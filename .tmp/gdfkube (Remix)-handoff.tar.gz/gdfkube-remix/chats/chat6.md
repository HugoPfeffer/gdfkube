# Approval System Logic

_Started 2026-05-04 12:27 UTC_

---

## User

Adjust the aproval system logic. Currently creating a new form either through the admin user or the normal user it skips the aproval and goes directly to provisioning.

## Assistant

_[tool: read_file]_

_[tool: read_file]_

_[tool: read_file]_

Now I can see the issue. In the `submit` function in `new-request.jsx`, after form submission it sets `status: "provisioning"` directly, skipping the approval stage. It should set `status: "approval"` instead and route to the approvals or request detail page showing the pending approval state.

_[tool: read_file]_

I see the problem. In `new-request.jsx`, the `submit` function sets `status: "provisioning"` and navigates directly to the request detail with `fresh: true` (which shows a "now provisioning" toast). It should set `status: "approval"` and navigate appropriately.

I also need to update the toast message in the main App and handle the navigation for the approval flow.

_[tool: str_replace_edit]_

Now update the App's navigate handler to show an appropriate toast for submitted-for-approval requests:

_[tool: str_replace_edit]_

_[tool: done]_

The approval logic is fixed. Now when submitting a new request (from either role), it:

1. **Sets status to `"approval"`** instead of `"provisioning"` — the request enters the approval queue
2. **Populates approval metadata** (justification, policy checks, waiting time) so it shows up properly in the Approvals page
3. **Shows an "awaiting approval" toast** instead of the "now provisioning" one

The request will appear in the admin's Approvals queue, where it must be approved before proceeding to provisioning.

## User

Apply comment

## Assistant

_[tool: read_file]_

_[tool: grep]_

The issue is that `navigator.clipboard.writeText` doesn't work in sandboxed iframes. I need to use a fallback approach.

_[tool: str_replace_edit]_

_[tool: done]_

Fixed the copy buttons in the template editor. The issue was that `navigator.clipboard.writeText` doesn't work in sandboxed iframes — replaced all instances with a helper that falls back to `document.execCommand('copy')` via a temporary textarea.

